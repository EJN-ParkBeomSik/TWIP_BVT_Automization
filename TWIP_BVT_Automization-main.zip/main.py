from login import login
from window_setting import window_setting
from real_done import donation
from mission_done import mission_done


def main():
    login()
    window_setting()
    donation()
    mission_done()

if __name__ == "__main__":
    main()