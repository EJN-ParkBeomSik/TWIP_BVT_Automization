# TWIP_BVT_Automization
TWIP 기본기능 테스트 자동화 with pyautogui

# Requirements
    python 3.6 이상
    PyAutoGUI 0.9.53
    keyboard 0.13.5

# Installation
    pip install pyautogui 
    pip install keyboard
    git clone https://github.com/EJN-ParkBeomSik/TWIP_BVT_Automization
    
# 크롬 시작 및 로그인 Usage
    이미지를 자신의 컴퓨터 상황에 맞게 설정한다. (asset 에 있는 이미지를 새로 캡쳐하여 저장. default : 1440p 기준)
    크롬 브라우저 주소창에서 한/영 상태가 영어인지 확인한다.
    바탕화면에 크롬 아이콘이 보이도록 조정한다.
    python login_test.py

# 후원 Useage
    현재 초기설정이 까다로움. 추후 개선예정
    이미지를 자신의 컴퓨터 상황에 맞게 설정한다. (asset 에 있는 이미지를 새로 캡쳐하여 저장. default : 1440p 기준)
    후원페이지, Alert Box 오버레이 페이지, 트윕 마이페이지 잔액부분이 보이게 크롬을 조정한다.
    python real_done.py
